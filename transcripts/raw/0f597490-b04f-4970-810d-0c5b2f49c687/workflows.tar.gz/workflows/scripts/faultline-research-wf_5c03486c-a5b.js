export const meta = {
  name: 'faultline-research',
  description: 'Research RL gym API design, agent harness patterns, sandbox/harness separation, and Modal deployment specifics; synthesize a design brief for PLAN.md',
  phases: [
    { title: 'Research', detail: '3 parallel researchers (gym+harness, sandbox+faults, modal)' },
    { title: 'Synthesize', detail: 'merge into one design brief' },
  ],
}

const BRIEF = {
  type: 'object',
  properties: {
    summary: { type: 'string', description: '2-4 paragraphs of the key takeaways' },
    recommendations: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          rationale: { type: 'string' },
          source: { type: 'string' },
        },
        required: ['title', 'rationale'],
      },
    },
    contracts: { type: 'string', description: 'Proposed concrete API/interface shapes (JSON, python signatures, MCP tool names) as markdown' },
    pitfalls: { type: 'array', items: { type: 'string' } },
    sources: { type: 'array', items: { type: 'string' } },
  },
  required: ['summary', 'recommendations', 'contracts', 'pitfalls', 'sources'],
}

const CONTEXT = [
  'PROJECT CONTEXT (read carefully, then research):',
  'We are building "Faultline": a mini agent harness with a browser view, for an Anthropic Platform SWE take-home (Theme 3 Systems & Reliability / Theme 4 Evals). An LLM agent (Anthropic API, configurable model, default claude-haiku-4-5) runs REAL shell commands to read files, edit code and run tests inside an isolated environment. The environment deliberately simulates failures: missing files, denied writes, and a completed write whose response times out (write succeeded but the ack was lost). The UI shows commands, output, file changes and recovery.',
  '',
  'Repo layout (monorepo, each deployed separately on Modal, environment "local"):',
  '- apps/web : shadcn/ui + Vite app, hosted directly on Modal (static site per https://modal.com/docs/guide/servers)',
  '- services/agent-harness : owns the model loop (Anthropic API). ONLY these model-calling functions receive the Modal secret "anthropic-api". Exposes an HTTP/SSE API the browser talks to.',
  '- services/sandbox-env : exposes shell execution over MCP (streamable HTTP), provisions per-episode workspaces, applies faults. A small gym: reset / step / observe / evaluate. Controller, grader and fault plan live OUTSIDE the command sandbox (the shell the agent runs in must not see the fault plan or grader).',
  'Verbose unified structured logging across all three. Evidence of runs kept in a gitignored runs/ folder.',
  'Modal client 1.5.5, Python 3.11, anthropic SDK python. Node 21, pnpm.',
  '',
  'Return raw structured data; your final output is consumed by a synthesizer, not a human. Be concrete: cite exact API names, signatures and URLs you verified. Use WebSearch/WebFetch to verify; do not rely on memory for library APIs. Do NOT write any files in the repo.',
  '',
].join('\n')

const P1 = [
  'YOUR DIMENSION: RL gym API design + agent harness patterns.',
  'Research and report:',
  '1. Gymnasium-style env API (reset/step/observe/evaluate, seeds, info dict, truncation vs termination) and how coding-agent gyms adapt it: SWE-Gym, SWE-bench harness, OpenHands runtime/action-execution-server, SWE-agent ACI, mini-swe-agent (single bash tool, one command per step), AgentBench, Terminal-Bench, BrowserGym. What is the minimal clean episode contract for a shell agent gym? What goes in observation vs info? How is reward/evaluate computed and why the grader is outside the sandbox.',
  '2. Agent harness patterns: Anthropic "Building effective agents" + Claude Code bash tool loop; how harnesses represent tool results (stdout/stderr/exit code, truncation, is_error), max-steps, stuck detection, and trajectory logging. What makes a harness observable for a browser UI (event stream shapes: turn/tool_call/tool_result/file_diff/fault_injected/recovered/evaluated).',
  '3. Recommend the exact event schema and episode/step JSON contract for our project, and the system prompt strategy for a recovery-oriented shell agent (verify after failure, re-read after timeout, idempotent writes).',
].join('\n')

const P2 = [
  'YOUR DIMENSION: sandbox/harness separation, fault injection, and security boundary.',
  'Research and report:',
  '1. How production agent platforms separate the model loop from tool execution: OpenHands action-execution server, E2B, Daytona, Modal Sandboxes, Anthropic Managed Agents (harness vs deployment split), Docker-based SWE-bench. Which process holds the provider API key, which holds the workspace, how they talk (HTTP/MCP/websocket).',
  '2. MCP (Model Context Protocol) streamable HTTP transport in 2026: the python "mcp" SDK and FastMCP server exposing tools over HTTP, session handling (Mcp-Session-Id header), how a python client calls tools (mcp.client.streamable_http streamablehttp_client + ClientSession), stateless_http mode, mounting into an ASGI app (fastmcp http_app / mcp streamable_http_app), exact import paths and current versions. Verify against the actual repo docs (https://github.com/modelcontextprotocol/python-sdk, https://gofastmcp.com).',
  '3. Fault injection design: chaos-engineering style fault plans (seeded, declarative, per-path/per-op triggers, one-shot vs sticky, hit counts), how to implement "missing file", "EACCES denied write", and "write completed but response timed out" (ack-lost) at the tool-execution boundary WITHOUT the sandbox shell being able to see the plan; how to make timeouts realistic (the write actually lands, the client sees a timeout error, the agent must re-verify with cat/ls before retrying, idempotency). How to detect and grade recovery (agent verified state before retrying; no duplicate appends; final tests pass).',
  '4. Security boundary recommendations: which secrets go where, no provider key in sandbox, sandbox network off, per-episode workspace isolation, resource limits, how the grader/fault plan stays out of the sandbox filesystem.',
  'Propose exact MCP tool names + JSON schemas (e.g. run_command, read_file, write_file, list_dir) and gym HTTP routes (POST /reset, POST /step, GET /observe, POST /evaluate) with request/response shapes, plus the fault plan JSON schema.',
].join('\n')

const P3 = [
  'YOUR DIMENSION: Modal deployment specifics (modal python client 1.5.x), verified against https://modal.com/docs (fetch the pages; do not rely on memory).',
  'Research and report EXACT, verified code shapes for:',
  '1. Hosting a built Vite static site directly on Modal per https://modal.com/docs/guide/servers (the newer @app.server() Server primitive) and/or @modal.web_server: image build steps (node install, pnpm build inside image via run_commands or add_local_dir), serving dist/ with python http.server or a static server, port, startup_timeout, unauthenticated=True, how the public URL is formed for environment "local" (workspace--app-label-function-label-local.modal.run or similar), custom labels, min_containers to avoid cold starts. Also fetch https://modal.com/docs/reference/modal.Server if it exists.',
  '2. Hosting an ASGI app (FastAPI + SSE streaming + an MCP streamable-http app mounted) via @modal.asgi_app on Modal; CORS; concurrency (@modal.concurrent), timeouts, how long-lived SSE streams behave on Modal web endpoints (limits), fetch https://modal.com/docs/examples/mcp_server_stateless and https://modal.com/docs/guide/webhooks and https://modal.com/docs/guide/streaming-endpoints.',
  '3. Modal Sandboxes API (https://modal.com/docs/guide/sandbox, https://modal.com/docs/reference/modal.Sandbox): Sandbox.create(...) args (app, image, timeout, workdir, block_network, cpu, memory, secrets), sb.exec(...) with stdout/stderr, .wait(), returncode, sb.open()/filesystem API, sb.terminate(), Sandbox.from_id, looking up the app from inside a deployed function (modal.App.lookup(name, create_if_missing=True)), idle_timeout, how to reuse one sandbox across steps in an episode, cost. Alternative: per-episode workspace directory with subprocess inside the same container as the sandbox-env service (tradeoffs, isolation, simplicity).',
  '4. Secrets: modal.Secret.from_name("anthropic-api") attached ONLY to specific functions; env var exposure; verifying other functions do not get it. Deploying separately with "modal deploy -e local path/to/app.py", app names, cross-app calls via modal.Function.from_name(app_name, fn_name, environment_name=...), and "modal serve" for dev.',
  '5. Logging: structured JSON to stdout, "modal app logs <name> -e local", request IDs, and a recommended unified log line format across python + browser.',
  '6. Frontend->backend: the browser must call the harness URL; how to inject the deployed harness URL into the Vite build (VITE_ env at build time vs a runtime config.json served by the web server), and CORS config on the harness.',
  'Include verified doc URLs and gotchas for modal 1.5.x (modal.Image.debian_slim(python_version=...), add_local_dir copy=True vs mounted at runtime, pip_install vs uv_pip_install, @app.function vs @app.cls, min_containers, scaledown_window).',
].join('\n')

phase('Research')
const briefs = await parallel([
  () => agent(CONTEXT + P1, { label: 'research:gym+harness', phase: 'Research', schema: BRIEF, model: 'opus' }),
  () => agent(CONTEXT + P2, { label: 'research:sandbox+faults', phase: 'Research', schema: BRIEF, model: 'opus' }),
  () => agent(CONTEXT + P3, { label: 'research:modal', phase: 'Research', schema: BRIEF, model: 'opus' }),
])

const ok = briefs.filter(Boolean)
log(ok.length + '/3 research briefs returned')

phase('Synthesize')
const SYN = [
  'You are the synthesizer. Below are ' + ok.length + ' research briefs (JSON). Merge them into ONE design brief in markdown, for use by the lead engineer writing PLAN.md and by 3 implementation agents. Resolve conflicts explicitly. Must contain these sections:',
  '1. Architecture (3 services, trust boundaries, which process holds what, data flow diagram in ascii)',
  '2. Gym contract: reset/step/observe/evaluate HTTP routes with exact JSON request/response; episode + fault plan schema; the three faults and precisely how each is implemented at the tool boundary; recovery grading rules.',
  '3. MCP surface: exact tool names/schemas exposed by sandbox-env over streamable HTTP; exact python imports for server and client (verified); session handling.',
  '4. Harness loop: Anthropic API usage (python SDK, configurable model via ANTHROPIC_MODEL, default claude-haiku-4-5; tool definitions; loop; max steps; error handling), event stream schema for the browser (SSE), system prompt strategy.',
  '5. Modal deployment: exact decorators/args per service, image definitions, secret attachment (only the harness model-calling function gets anthropic-api), URL shapes for env local, deploy commands, static site hosting for apps/web, config injection of harness URL into the web app, CORS.',
  '6. Unified logging format.',
  '7. Verification plan: what a one-real-shell/MCP-round-trip smoke test looks like end-to-end, and what evidence to save under runs/.',
  '8. Risks/pitfalls list, and scope cuts ranked by what to drop first.',
  'Keep it dense and concrete; include code snippets where they matter. Output ONLY the markdown.',
  '',
  'BRIEFS:',
  JSON.stringify(ok, null, 2),
].join('\n')
const design = await agent(CONTEXT + SYN, { label: 'synthesize:design-brief', phase: 'Synthesize', model: 'opus' })

return { design, briefs: ok }
